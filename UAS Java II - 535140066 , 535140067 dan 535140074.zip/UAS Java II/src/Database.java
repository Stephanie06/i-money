import java.sql.*;
import java.util.Vector;

public class Database {
    private Connection conn = null;
    boolean adaUser = false;
    String usernameS,passwordS, fullname;
    int counter = 0;
    Double balanced;

    public Database() throws Exception{
        Class.forName("com.mysql.jdbc.Driver"); // buat download driver mysql

        conn = DriverManager.getConnection("jdbc:mysql://172.16.113.171:3306/imoney", "Andree", "123123");
        //localhost:nomor_port_mysql/NamaDatabase //username default = "root" //password = ""
    }

    public boolean isConnected(){
        return(conn!= null); //connected maka tidak sama dengan null;
    }

    public boolean userLogin (
            String username,
            String password
    ) throws Exception{
        String query = "SELECT * FROM user WHERE username = ? AND password = ?";
        PreparedStatement statement = conn.prepareStatement(query); //preparedStatement digunakan ketika ada tanda tanya tanda tanya gitu
        statement.setString(1, username); //statement.setString karena tipenya kolom yang pertama adalah adalah string
        statement.setString(2, password );
        usernameS = username;
        passwordS = password;

        String query2 = "SELECT * FROM user WHERE username = '" + username + "' AND password = '" + password + "'";
        //jika tidak ada tanda tanya (query biasa) maka pakainya Statement saja, bukan preparedStatement

        ResultSet resultSet = statement.executeQuery(query2);

        while(resultSet.next()){
            counter +=1;
        }

        if(counter == 1){
            adaUser = true;
        }
        else{
            adaUser = false;
        }

        statement.close();
        counter = 0;

        return adaUser;
    }

    public void insertUser(
            String fullname,
            String username,
            String email,
            String password
    ) throws Exception {
        String query = "INSERT INTO user(fullname,username,email,password) values (?,?,?,?)";
        PreparedStatement statement = conn.prepareStatement(query); //preparedStatement digunakan ketika ada tanda tanya tanda tanya gitu
        statement.setString(1, fullname); //statement.setString karena tipenya kolom yang pertama adalah adalah string
        statement.setString(2, username);
        statement.setString(3, email);
        statement.setString(4, password);

        statement.execute(); //untuk menjalankan query
        statement.close(); //untuk menutup statement
        // berlaku untuk semua kayak select juga.
    }

    public void updateUser(
            String fullname,
            String password,
            String username
    ) throws Exception {
        String query = "UPDATE user SET fullname = ?, password = ? WHERE username = ?";
        PreparedStatement statement = conn.prepareStatement(query); //preparedStatement digunakan ketika ada tanda tanya tanda tanya gitu
        statement.setString(1, fullname); //statement.setString karena tipenya kolom yang pertama adalah adalah string
        statement.setString(2, password);
        statement.setString(3, username);

        statement.execute(); //untuk menjalankan query
        statement.close(); //untuk menutup statement
        // berlaku untuk semua kayak select juga.
    }

    public void insertExpenseUsername(
            String username,
            String tanggal
    ) throws Exception {
        String query = "INSERT INTO expensemanager(username, tanggal) values (?,?)";
        PreparedStatement statement = conn.prepareStatement(query); //preparedStatement digunakan ketika ada tanda tanya tanda tanya gitu
        statement.setString(1, username); //statement.setString karena tipenya kolom yang pertama adalah adalah string
        statement.setString(2, tanggal);
        statement.execute(); //untuk menjalankan query
        statement.close(); //untuk menutup statement
        // berlaku untuk semua kayak select juga.
    }
/*
    public void insertIncome(
            Double income
    ) throws Exception {
        String query = "UPDATE expensemanager set income = ? WHERE username = '" + usernameS + "'";
        PreparedStatement statement = conn.prepareStatement(query); //preparedStatement digunakan ketika ada tanda tanya tanda tanya gitu
        statement.setDouble(1, income); //statement.setString karena tipenya kolom yang pertama adalah adalah string

        statement.execute(); //untuk menjalankan query
        statement.close(); //untuk menutup statement
        // berlaku untuk semua kayak select juga.
    }

    public void insertExpense(
            Double expense,
            String notes
    ) throws Exception {
        String query = "UPDATE expensemanager SET expense = ? , notes = ? WHERE username = '" + usernameS + "'";
        PreparedStatement statement = conn.prepareStatement(query); //preparedStatement digunakan ketika ada tanda tanya tanda tanya gitu
        statement.setDouble(1, expense); //statement.setString karena tipenya kolom yang pertama adalah adalah string
        statement.setString(2, notes);

        statement.execute(); //untuk menjalankan query
        statement.close(); //untuk menutup statement
        // berlaku untuk semua kayak select juga.

    }
*/

    public void insertIncome(
            String tanggal,
            Double transaksi,
            String notes
    ) throws Exception {
        String query = "INSERT INTO expensemanager(username,tanggal,transaksi,notes) VALUES ('" + usernameS + "',?, ?, ?)";

        PreparedStatement statement = conn.prepareStatement(query); //preparedStatement digunakan ketika ada tanda tanya tanda tanya gitu
        statement.setString(1, tanggal);//statement.setString karena tipenya kolom yang pertama adalah adalah string
        statement.setDouble(2, transaksi);
        statement.setString(3, notes);

        statement.execute(); //untuk menjalankan query
        statement.close(); //untuk menutup statement
        // berlaku untuk semua kayak select juga.

    }

    public void insertExpense(
            String tanggal,
            Double transaksi,
            String notes
    ) throws Exception {
        String query = "INSERT INTO expensemanager(username,tanggal,transaksi,notes) VALUES ('" + usernameS + "',?, ?, ?)";
        PreparedStatement statement = conn.prepareStatement(query); //preparedStatement digunakan ketika ada tanda tanya tanda tanya gitu
        statement.setString(1, tanggal);//statement.setString karena tipenya kolom yang pertama adalah adalah string
        statement.setDouble(2, transaksi);
        statement.setString(3, notes);

        statement.execute(); //untuk menjalankan query
        statement.close(); //untuk menutup statement
        // berlaku untuk semua kayak select juga.

    }
/*
    public double selectExpense () throws Exception{
        String query = "SELECT expense FROM expensemanager WHERE username = '" + usernameS +"'";
        Statement statement = this.conn.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        while (resultSet.next()){
            expenseBefore = resultSet.getDouble("expense");
        }
        statement.close();

        return expenseBefore;
    }

*/

    public String selectFullname(String username)throws SQLException{
        String query = ("SELECT fullname FROM USER WHERE username = '" + username + "'");
        Statement statement = this.conn.createStatement();
        ResultSet rs = statement.executeQuery(query);
        while(rs.next()){
            fullname = rs.getString("fullname");
        }
        return fullname;
    }

    public Double Balance(String username)throws SQLException{
        String query = ("SELECT sum(transaksi) FROM expensemanager WHERE username = '" + username + "'");
        Statement statement = this.conn.createStatement();
        ResultSet rs = statement.executeQuery(query);
        while(rs.next()){
            balanced = rs.getDouble("sum(transaksi)");
        }
        return balanced;
    }

    public Vector<Vector<Object>> selectBalance(String username) throws SQLException{
        String query1 = ("SELECT * FROM expensemanager WHERE username = '" + username  + "'");
        Statement statement= this.conn.createStatement();
        ResultSet rs = statement.executeQuery(query1);

        Vector<Vector<Object>> data = new Vector<Vector<Object>>(); // return the resultset as Vector
        while (rs.next()) {
            Vector<Object> v = new Vector<Object>();
            v.add(rs.getString("username"));
            v.add(rs.getString("tanggal"));
            v.add(rs.getString("transaksi"));
            v.add(rs.getString("notes"));
            data.add(v);
        }
        return data;
    }




}
