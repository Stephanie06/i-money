﻿import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Arc2D;
import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;

/**
 * Created by USER on 12/7/2016.
 */


public class Tester {

    boolean adaUser;
    double income,expenseNow;
    public String usernameSaver,passwordSaver;

    private void displayGUI() throws Exception{
        Database db = new Database();


        JFrame frameUtama = new JFrame("Welcome to iMoney");
        frameUtama.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        JPanel contentPane = new JPanel();

        contentPane.setOpaque(true);
        contentPane.setBackground(Color.WHITE);
        contentPane.setLayout(null);

        JPanel contentPaneSignup = new JPanel();
        contentPaneSignup.setOpaque(true);
        contentPaneSignup.setBackground(Color.WHITE);
        contentPaneSignup.setLayout(null);

        JLabel label = new JLabel("                              Welcome to iMoney , Balance your Expense just in one Click !                                                                       ", JLabel.CENTER);
        label.setSize(500,30);
        label.setLocation(5,5);

        JLabel labelUsername = new JLabel("Username : ");
        JLabel labelPassword = new JLabel("Password : ");
        labelUsername.setSize(80,30);
        labelUsername.setLocation(650,5);
        labelPassword.setSize(80,30);
        labelPassword.setLocation(880,5);

        JTextField textBoxUsername = new JTextField(15);
        JPasswordField textBoxPassword = new JPasswordField(15);
        textBoxUsername.setSize(140,30);
        textBoxUsername.setLocation(720,5);
        textBoxPassword.setSize(140,30);
        textBoxPassword.setLocation(950,5);

        JButton buttonLogin = new JButton("Login");
        JButton buttonSignup = new JButton("Sign Up");
        buttonLogin.setSize(100,30);
        buttonLogin.setLocation(1100,5);
        buttonSignup.setSize(100,30);
        buttonSignup.setLocation(1220,5);

        contentPane.add(label);
        contentPane.add(labelUsername);
        contentPane.add(labelPassword);
        contentPane.add(textBoxUsername);
        contentPane.add(textBoxPassword);
        contentPane.add(buttonLogin);
        contentPane.add(buttonSignup);

        frameUtama.setContentPane((new JLabel(new ImageIcon("C:\\Users\\USER\\Desktop\\UAS Java II\\src\\Connected.jpg"))));
        frameUtama.setLayout(new FlowLayout());
        frameUtama.add(label);
        frameUtama.add(labelUsername);
        frameUtama.add(textBoxUsername);
        frameUtama.add(labelPassword);
        frameUtama.add(textBoxPassword);
        frameUtama.add(buttonLogin);
        frameUtama.add(buttonSignup);
        frameUtama.setSize(1366,725);
        frameUtama.setLocation(0,0);
        frameUtama.setVisible(true);
//-------------------------------------------------FRAME SIGNUP---------------------------------------------------------
        JFrame frameSignup = new JFrame("Sign Up");
        frameSignup.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel labelFullnameSignup = new JLabel("Fullname");
        JLabel labelUsernameSignup = new JLabel("Username");
        JLabel labelEmailSignup = new JLabel("Email");
        JLabel labelPasswordSignup = new JLabel("Password");
        JLabel labelRetypeSignup = new JLabel("Retype");
        JLabel labelPassword2Signup = new JLabel("Password");

        labelFullnameSignup.setSize(100,10);
        labelFullnameSignup.setLocation(10,15);
        labelUsernameSignup.setSize(100,10);
        labelUsernameSignup.setLocation(10,40);
        labelEmailSignup.setSize(100,10);
        labelEmailSignup.setLocation(10,65);
        labelPasswordSignup.setSize(100,10);
        labelPasswordSignup.setLocation(10,90);
        labelRetypeSignup.setSize(80,15);
        labelRetypeSignup.setLocation(10,115);
        labelPassword2Signup.setSize(100,10);
        labelPassword2Signup.setLocation(10,132);

        JTextField textBoxFullnameSu = new JTextField();
        JTextField textBoxUsernameSu = new JTextField();
        JTextField textBoxEmailSu = new JTextField();
        JPasswordField textBoxPasswordSu = new JPasswordField();
        JPasswordField textBoxPassword2Su = new JPasswordField();
        textBoxFullnameSu.setSize(140,25);
        textBoxFullnameSu.setLocation(120,10);
        textBoxUsernameSu.setSize(140,25);
        textBoxUsernameSu.setLocation(120,38);
        textBoxEmailSu.setSize(140,25);
        textBoxEmailSu.setLocation(120,66);
        textBoxPasswordSu.setSize(140,25);
        textBoxPasswordSu.setLocation(120,94);
        textBoxPassword2Su.setSize(140,25);
        textBoxPassword2Su.setLocation(120,122);

        JButton buttonSignupSU = new JButton("Sign Up");
        JButton buttonCancelSU = new JButton("Cancel");
        buttonSignupSU.setSize(80,20);
        buttonSignupSU.setLocation(60,160);
        buttonCancelSU.setSize(80,20);
        buttonCancelSU.setLocation(150,160);

        contentPaneSignup.add(labelFullnameSignup);
        contentPaneSignup.add(labelUsernameSignup);
        contentPaneSignup.add(labelEmailSignup);
        contentPaneSignup.add(labelPasswordSignup);
        contentPaneSignup.add(labelRetypeSignup);
        contentPaneSignup.add(labelPassword2Signup);
        contentPaneSignup.add(textBoxFullnameSu);
        contentPaneSignup.add(textBoxUsernameSu);
        contentPaneSignup.add(textBoxEmailSu);
        contentPaneSignup.add(textBoxPasswordSu);
        contentPaneSignup.add(textBoxPassword2Su);
        contentPaneSignup.add(buttonSignupSU);
        contentPaneSignup.add(buttonCancelSU);

        frameSignup.setContentPane(contentPaneSignup);
        frameSignup.setSize(300,300);
        frameSignup.setLocationByPlatform(true);
        frameSignup.setVisible(false);

        buttonSignupSU.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                if((textBoxPasswordSu.getText().equals(textBoxPassword2Su.getText())) && !textBoxFullnameSu.getText().equals("") && !textBoxFullnameSu.getText().equals("") && !textBoxUsernameSu.getText().equals("") && !textBoxEmailSu.getText().equals("") && !textBoxPasswordSu.getText().equals("") && !textBoxPassword2Su.getText().equals("") ){
                    try {
                        db.insertUser(textBoxFullnameSu.getText(), textBoxUsernameSu.getText(), textBoxEmailSu.getText(), textBoxPasswordSu.getText());
                        String timeStamp = new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());
                        db.insertExpenseUsername(textBoxUsernameSu.getText(), timeStamp);
                        JOptionPane.showMessageDialog(null,"Registered !", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                        textBoxFullnameSu.setText("");
                        textBoxUsernameSu.setText("");
                        textBoxEmailSu.setText("");
                        textBoxPasswordSu.setText("");
                        textBoxPassword2Su.setText("");
                        frameSignup.dispose();
                        frameUtama.setVisible(true);
                    }
                    catch (com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException eSqlSu){
                        JOptionPane.showMessageDialog(null,"This email or username is already used", "Warning !", JOptionPane.INFORMATION_MESSAGE);;
                    }
                    catch (Exception eSu){
                        eSu.printStackTrace();
                    }
                }
                else if(!textBoxPasswordSu.getText().equals(textBoxPassword2Su.getText())){
                    textBoxPasswordSu.setText("");
                    textBoxPassword2Su.setText("");
                    JOptionPane.showMessageDialog(null,"Password Mismatch", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                }
                else if((textBoxPasswordSu.getText().equals(""))){
                    JOptionPane.showMessageDialog(null,"Please Fill the Password !", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                }
                else{
                    JOptionPane.showMessageDialog(null,"All field required !", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        buttonCancelSU.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                textBoxFullnameSu.setText("");
                textBoxUsernameSu.setText("");
                textBoxEmailSu.setText("");
                textBoxPasswordSu.setText("");
                textBoxPassword2Su.setText("");
                frameSignup.dispose();
                textBoxUsername.setText("");
                textBoxPassword.setText("");
                frameUtama.setVisible(true);
            }
        });
//----------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------FRAME ADD INCOME---------------------------------------------------


        JFrame frameAddIncomeIs = new JFrame("Add your income this month ");
        frameAddIncomeIs.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel contentPaneIncomeIs = new JPanel();
        contentPaneIncomeIs.setOpaque(true);
        contentPaneIncomeIs.setBackground(Color.WHITE);
        contentPaneIncomeIs.setLayout(null);

        JLabel labelIncomeIs = new JLabel("Income : ");
        labelIncomeIs.setSize(80,30);
        labelIncomeIs.setLocation(10,5);

        JLabel labelNotesInIs = new JLabel("Notes : ");
        labelNotesInIs.setSize(150,30);
        labelNotesInIs.setLocation(200,5);

        JTextField textBoxIncomeIs = new JTextField();
        textBoxIncomeIs.setSize(140,30);
        textBoxIncomeIs.setLocation(10,30);

        JTextField textBoxNotesInIs = new JTextField();
        textBoxNotesInIs.setSize(140,30);
        textBoxNotesInIs.setLocation(200,30);

        JButton buttonAddIncomeInIs = new JButton("Add");
        JButton buttonCancelIncomeInIs = new JButton("Cancel");
        buttonAddIncomeInIs.setSize(120,25);
        buttonAddIncomeInIs.setLocation(50,100);
        buttonCancelIncomeInIs.setSize(120,25);
        buttonCancelIncomeInIs.setLocation(200,100);

        contentPaneIncomeIs.add(labelIncomeIs);
        contentPaneIncomeIs.add(textBoxIncomeIs);
        contentPaneIncomeIs.add(labelNotesInIs);
        contentPaneIncomeIs.add(textBoxNotesInIs);
        contentPaneIncomeIs.add(buttonAddIncomeInIs);
        contentPaneIncomeIs.add(buttonCancelIncomeInIs);

        frameAddIncomeIs.setContentPane(contentPaneIncomeIs);
        frameAddIncomeIs.setSize(400,200);
        frameAddIncomeIs.setLocation(500,260);
        frameAddIncomeIs.setVisible(false);


        buttonAddIncomeInIs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                if(!textBoxIncomeIs.getText().equals("")){
                    try{
                        String timeStamp = new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());
                        income = Double.parseDouble(textBoxIncomeIs.getText());
                        db.insertIncome(timeStamp, income, textBoxNotesInIs.getText());
                        income = 0;
                        textBoxIncomeIs.setText("");
                        textBoxNotesInIs.setText("");
                    }
                    catch (java.lang.NumberFormatException eExpenseNumberFormatException){
                        JOptionPane.showMessageDialog(null,"Please fill the income field with number only", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                    }
                    catch (Exception eIncome){
                        eIncome.printStackTrace();
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"Please fill the income field", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        buttonCancelIncomeInIs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                textBoxIncomeIs.setText("");
                textBoxNotesInIs.setText("");
                frameAddIncomeIs.dispose();
            }
        });
//----------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------FRAME ADD EXPENSE---------------------------------------------------


        JFrame frameAddExpenseIs = new JFrame("Add your expense today");
        frameAddExpenseIs.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel contentPaneExpenseIs = new JPanel();
        contentPaneExpenseIs.setOpaque(true);
        contentPaneExpenseIs.setBackground(Color.WHITE);
        contentPaneExpenseIs.setLayout(null);


        JLabel labelExpenseIs = new JLabel("Expense : ");
        JLabel labelNotesIs = new JLabel("Notes : ");
        labelExpenseIs.setSize(80,30);
        labelExpenseIs.setLocation(10,5);
        labelNotesIs.setSize(150,30);
        labelNotesIs.setLocation(200,5);

        JTextField textBoxExpenseIs = new JTextField();
        JTextField textBoxNotesIs = new JTextField();
        textBoxExpenseIs.setSize(140,30);
        textBoxExpenseIs.setLocation(10,30);
        textBoxNotesIs.setSize(140,30);
        textBoxNotesIs.setLocation(200,30);

        JButton buttonAddExpenseInIs = new JButton("Add");
        JButton buttonCancelExpenseInIs = new JButton("Cancel");
        buttonAddExpenseInIs.setSize(120,25);
        buttonAddExpenseInIs.setLocation(50,100);
        buttonCancelExpenseInIs.setSize(120,25);
        buttonCancelExpenseInIs.setLocation(200,100);

        contentPaneExpenseIs.add(labelExpenseIs);
        contentPaneExpenseIs.add(labelNotesIs);
        contentPaneExpenseIs.add(textBoxExpenseIs);
        contentPaneExpenseIs.add(textBoxNotesIs);
        contentPaneExpenseIs.add(buttonAddExpenseInIs);
        contentPaneExpenseIs.add(buttonCancelExpenseInIs);

        frameAddExpenseIs.setContentPane(contentPaneExpenseIs);
        frameAddExpenseIs.setSize(400 ,200);
        frameAddExpenseIs.setLocation(500,260);
        frameAddExpenseIs.setVisible(false);


        buttonAddExpenseInIs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                if(!textBoxExpenseIs.getText().equals("") && !textBoxNotesIs.getText().equals("")){
                    try{
                        //expenseBefore = db.selectExpense();
                        //System.out.print(expenseBefore);
                        String timeStamp = new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());

                        expenseNow = Double.parseDouble(textBoxExpenseIs.getText());

                        db.insertExpense(timeStamp,expenseNow*(-1),textBoxNotesIs.getText());
                        textBoxExpenseIs.setText("");
                        textBoxNotesIs.setText("");
                    }
                    catch (java.lang.NumberFormatException eExpenseNumberFormatException){
                        JOptionPane.showMessageDialog(null,"Please fill the expense field with number only", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                    }
                    catch (Exception eExpense){
                        eExpense.printStackTrace();
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"Please fill the income field", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        buttonCancelExpenseInIs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                frameAddExpenseIs.dispose();
                textBoxExpenseIs.setText("");
                textBoxNotesIs.setText("");
            }
        });
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------FRAME ABOUT-------------------------------------------------------------

        JFrame frameAbout = new JFrame("About");
        frameAbout.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frameAbout.setSize(425,200);
        frameAbout.setLocation(520,280);

        JPanel contentPaneAbout = new JPanel();
        contentPaneAbout.setOpaque(true);
        contentPaneAbout.setBackground(Color.WHITE);
        contentPaneAbout.setLayout(null);

        JLabel labelProgram = new JLabel("Program ini dibangun dan dipublish oleh : ", JLabel.CENTER);
        labelProgram.setSize(300,30);
        labelProgram.setLocation(85,0);

        JLabel labelNamaKelompok = new JLabel("Nama Kelompok : ");
        labelNamaKelompok.setSize(150,30);
        labelNamaKelompok.setLocation(100,13);

        JLabel label535140066 = new JLabel("535140066");
        label535140066.setSize(150,30);
        label535140066.setLocation(100,28);

        JLabel label535140067 = new JLabel("535140067");
        label535140067.setSize(150,30);
        label535140067.setLocation(100,43);

        JLabel label535140074 = new JLabel("535140074");
        label535140074.setSize(150,30);
        label535140074.setLocation(100,58);

        JLabel labelSB = new JLabel("Stephanie Budianto");
        labelSB.setSize(150,30);
        labelSB.setLocation(180,28);

        JLabel labelAP = new JLabel("Andree Phanderson");
        labelAP.setSize(150,30);
        labelAP.setLocation(180,43);

        JLabel labelAT = new JLabel("Alfred Tanuwijaya");
        labelAT.setSize(150,30);
        labelAT.setLocation(180,58);

        JButton buttonOK = new JButton("OK");
        buttonOK.setSize(150,25);
        buttonOK.setLocation(150,85);

        buttonOK.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                frameAbout.dispose();
            }
        });

        contentPaneAbout.add(labelProgram);
        contentPaneAbout.add(labelNamaKelompok);
        contentPaneAbout.add(label535140066);
        contentPaneAbout.add(label535140067);
        contentPaneAbout.add(label535140074);
        contentPaneAbout.add(labelSB);
        contentPaneAbout.add(labelAP);
        contentPaneAbout.add(labelAT);
        contentPaneAbout.add(buttonOK);
        frameAbout.setContentPane(contentPaneAbout);

        frameAbout.setVisible(false);
//----------------------------------------------------------------------------------------------------------------------

// --------------------------------------FRAME EDIT PROFILE-------------------------------------------------------------

        JFrame frameEP = new JFrame("Edit Profile");
        frameEP.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frameEP.setSize(400,400);
        frameEP.setLocation(0,0);

        JPanel contentPaneEP = new JPanel();
        contentPaneEP.setOpaque(true);
        contentPaneEP.setBackground(Color.WHITE);
        contentPaneEP.setLayout(null);

        JLabel labelFullnameEP = new JLabel("Fullname");
        labelFullnameEP.setSize(80,25);
        labelFullnameEP.setLocation(5,5);

        JLabel labelOldPasswordEP = new JLabel("Old Password");
        labelOldPasswordEP.setSize(100,25);
        labelOldPasswordEP.setLocation(5,38);

        JLabel labelPasswordEP = new JLabel("New Password");
        labelPasswordEP.setSize(100,25);
        labelPasswordEP.setLocation(5,71);

        JLabel labelRetypeEP = new JLabel("Retype");
        labelRetypeEP.setSize(100,25);
        labelRetypeEP.setLocation(5,104);

        JLabel labelPassword2EP = new JLabel("New Password");
        labelPassword2EP.setSize(100,25);
        labelPassword2EP.setLocation(5,124);

        JTextField textBoxFullnameEP = new JTextField();
        JPasswordField textBoxOPEP = new JPasswordField();
        JPasswordField textBoxPasswordEP = new JPasswordField();
        JPasswordField textBoxPassword2EP = new JPasswordField();
        textBoxFullnameEP.setSize(140,25);
        textBoxFullnameEP.setLocation(120,5);
        textBoxOPEP.setSize(140,25);
        textBoxOPEP.setLocation(120,38);
        textBoxPasswordEP.setSize(140,25);
        textBoxPasswordEP.setLocation(120,71);
        textBoxPassword2EP.setSize(140,25);
        textBoxPassword2EP.setLocation(120,114);

        JButton buttonSaveEP= new JButton("Save");
        JButton buttonCancelEP = new JButton("Cancel");
        buttonSaveEP.setSize(80,20);
        buttonSaveEP.setLocation(60,160);
        buttonCancelEP.setSize(80,20);
        buttonCancelEP.setLocation(150,160);


        buttonSaveEP.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                if(textBoxOPEP.getText().equals(passwordSaver) && !textBoxOPEP.getText().equals("") && !textBoxPasswordEP.equals(""))
                {
                    try{
                        db.updateUser(textBoxFullnameEP.getText(),textBoxPasswordEP.getText(),usernameSaver);
                        frameEP.dispose();
                        frameUtama.setVisible(true);
                        textBoxFullnameEP.setText("");
                        textBoxPasswordEP.setText("");
                        textBoxPassword2EP.setText("");
                    }
                    catch (Exception eSaveEP){
                        JOptionPane.showMessageDialog(null, "SQL Error", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                else if (!textBoxOPEP.getText().equals(passwordSaver))
                {
                    JOptionPane.showMessageDialog(null, "Wrong old password", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                }
                else if(!textBoxPasswordEP.getText().equals(textBoxPassword2EP.getText())){
                    JOptionPane.showMessageDialog(null, "New password doesn't match", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                    textBoxPasswordEP.setText("");
                    textBoxPassword2EP.setText("");
                }
                else{
                    JOptionPane.showMessageDialog(null, "All field required !", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });


        buttonCancelEP.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                frameEP.dispose();
                textBoxFullnameEP.setText("");
                textBoxPasswordEP.setText("");
                textBoxPassword2EP.setText("");
            }
        });

        contentPaneEP.add(labelFullnameEP);
        contentPaneEP.add(labelOldPasswordEP);
        contentPaneEP.add(labelPasswordEP);
        contentPaneEP.add(labelRetypeEP);
        contentPaneEP.add(labelPassword2EP);
        contentPaneEP.add(textBoxFullnameEP);
        contentPaneEP.add(textBoxPasswordEP);
        contentPaneEP.add(textBoxPassword2EP);
        contentPaneEP.add(textBoxOPEP);
        contentPaneEP.add(buttonSaveEP);
        contentPaneEP.add(buttonCancelEP);

        frameEP.setContentPane(contentPaneEP);
        frameEP.setVisible(false);

//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------FRAME TABEL-------------------------------------------------------------

        JFrame frameTabel = new JFrame("Be your Expense Manager");
        frameTabel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frameTabel.setSize(800 ,670);
        frameTabel.setLocation(250,20);


        JButton balancedTransaction = new JButton("See my balanced");
        balancedTransaction.setSize(150,60);
        balancedTransaction.setLocation(10,500);
        balancedTransaction.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try{
                    JOptionPane.showMessageDialog(null,db.Balance(usernameSaver), "Your Money Balanced", JOptionPane.INFORMATION_MESSAGE);
                }
                catch (SQLException eSQLE){
                    eSQLE.printStackTrace();
                }


            }
        });

        JButton cancelTabel = new JButton("Cancel");
        cancelTabel.setSize(150,60);
        cancelTabel.setLocation(610,500);
        cancelTabel.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                frameTabel.dispose();
            }
        });

        frameTabel.add(balancedTransaction);
        frameTabel.add(cancelTabel);
        frameTabel.setVisible(false);
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------FRAME TABEL 1-------------------------------------------------------------

        JFrame frameTabel1 = new JFrame("Income");
        frameTabel1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frameTabel1.setSize(800 ,670);
        frameTabel1.setLocation(250,20);



        JButton cancelTabel1 = new JButton("Cancel");
        cancelTabel1.setSize(150,60);
        cancelTabel1.setLocation(610,500);
        cancelTabel1.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                frameTabel1.dispose();
            }
        });

        frameTabel1.add(cancelTabel1);
        frameTabel1.setVisible(false);
//----------------------------------------------------------------------------------------------------------------------
// ----------------------------------------------FRAME TABEL 2-------------------------------------------------------------

        JFrame frameTabel2 = new JFrame("Expense");
        frameTabel2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frameTabel2.setSize(800 ,670);
        frameTabel2.setLocation(250,20);



        JButton cancelTabel2 = new JButton("Cancel");
        cancelTabel2.setSize(150,60);
        cancelTabel2.setLocation(610,500);
        cancelTabel2.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                frameTabel2.dispose();
            }
        });

        frameTabel2.add(cancelTabel2);
        frameTabel2.setVisible(false);
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------FRAME TABEL 3-----------------------------------------------------------

        JFrame frameTabel3 = new JFrame("Sort Income");
        frameTabel3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frameTabel3.setSize(800 ,670);
        frameTabel3.setLocation(250,20);



        JButton cancelTabel3 = new JButton("Cancel");
        cancelTabel3.setSize(150,60);
        cancelTabel3.setLocation(610,500);
        cancelTabel3.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                frameTabel3.dispose();
            }
        });

        frameTabel3.add(cancelTabel3);
        frameTabel3.setVisible(false);
//----------------------------------------------------------------------------------------------------------------------

        //----------------------------------------------FRAME TABEL 3-----------------------------------------------------------

        JFrame frameTabel4 = new JFrame("Sort Expense");
        frameTabel4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frameTabel4.setSize(800 ,670);
        frameTabel4.setLocation(250,20);



        JButton cancelTabel4 = new JButton("Cancel");
        cancelTabel4.setSize(150,60);
        cancelTabel4.setLocation(610,500);
        cancelTabel4.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                frameTabel4.dispose();
            }
        });

        frameTabel4.add(cancelTabel4);
        frameTabel4.setVisible(false);
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------FRAME AFTER LOGIN ------------------------------------------------------

        JFrame frameInside = new JFrame("Become your expense manager");
        frameInside.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel contentPaneInside = new JPanel();
        contentPaneInside.setOpaque(true);
        contentPaneInside.setBackground(Color.WHITE);
        contentPaneInside.setLayout(null);



/*
        JLabel labelIncomeIs = new JLabel("Income : ");
        JLabel labelExpenseIs = new JLabel("Expense : ");
        JLabel labelNotesIs = new JLabel("Notes : ");
        labelIncomeIs.setSize(80,30);
        labelIncomeIs.setLocation(100,5);
        labelExpenseIs.setSize(80,30);
        labelExpenseIs.setLocation(200,5);
        labelNotesIs.setSize(80,30);
        labelNotesIs.setLocation(300,5);

        JTextField textBoxIncomeIs = new JTextField();
        JTextField textBoxExpenseIs = new JTextField();
        textBoxIncomeIs.setSize(140,30);
        textBoxIncomeIs.setLocation(100,30);
        textBoxExpenseIs.setSize(140,30);
        textBoxExpenseIs.setLocation(200,30);

*/
        JMenuBar menuUtama = new JMenuBar();
        JMenu menuFile = new JMenu("≡≡≡");
        JMenuItem menuItemFileEP = new JMenuItem("Edit Profile");
        JMenuItem menuAbout = new JMenuItem("About");
        JMenuItem menuLogout = new JMenuItem("Log out");
        //JMenu menuFile = new JMenu("≡");
        //JMenuItem menuFileNewJavaProject = new JMenuItem("Java Project");

        //menuItemFileNew.add(menuFileNewJavaProject);
        menuFile.add(menuItemFileEP);
        menuFile.add(menuAbout);
        menuFile.add(menuLogout);
        menuUtama.add(menuFile);
        menuUtama.setSize(50,15);
        menuUtama.setLocation(5,5);

        JButton buttonBalance = new JButton("Show Record");
        JButton buttonAddIncomeIs = new JButton("Add Income");
        JButton buttonAddExpenseIs = new JButton("Add Expense");
        buttonAddIncomeIs.setSize(120,25);
        buttonAddIncomeIs.setLocation(5,50);
        buttonAddExpenseIs.setSize(120,25);
        buttonAddExpenseIs.setLocation(135,50);
        buttonBalance.setSize(150,25);
        buttonBalance.setLocation(265,50);
        JButton buttonShowIncomeIs = new JButton("Show income");
        buttonShowIncomeIs.setSize(120,25);
        buttonShowIncomeIs.setLocation(5,100);
        JButton buttonShowIncomeEs = new JButton("Show Expense");
        buttonShowIncomeEs.setSize(120,25);
        buttonShowIncomeEs.setLocation(135,100);
        JButton buttonShowBigIs = new JButton("Biggest Income");
        buttonShowBigIs.setSize(120,25);
        buttonShowBigIs.setLocation(5,150);
        JButton buttonShowBigEs = new JButton("Biggest Expense");
        buttonShowBigEs.setSize(120,25);
        buttonShowBigEs.setLocation(135,150);
        JButton buttonSortIs = new JButton("Sort Income");
        buttonSortIs.setSize(120,25);
        buttonSortIs.setLocation(5,200);
        JButton buttonSortEs = new JButton("Sort Expense");
        buttonSortEs.setSize(120,25);
        buttonSortEs.setLocation(135,200);

/*
        contentPaneInside.add(labelIncomeIs);
        contentPaneInside.add(labelExpenseIs);
        contentPaneInside.add(labelNotesIs);
        contentPaneInside.add(textBoxIncomeIs);
        contentPaneInside.add(textBoxExpenseIs);*/



        contentPaneInside.add(buttonAddIncomeIs);
        contentPaneInside.add(buttonAddExpenseIs);
        contentPaneInside.add(buttonBalance);
        contentPaneInside.add(buttonShowIncomeIs);
        contentPaneInside.add(buttonShowIncomeEs);
        contentPaneInside.add(buttonShowBigIs);
        contentPaneInside.add(buttonShowBigEs);
        contentPaneInside.add(buttonSortIs);
        contentPaneInside.add(buttonSortEs);
        contentPaneInside.add(menuUtama);
        //contentPaneInside.add();

        frameInside.setContentPane(contentPaneInside);
        frameInside.setSize(440,300);
        frameInside.setLocation(500,260);
        frameInside.setVisible(false);

        menuItemFileEP.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try{
                    textBoxFullnameEP.setText(db.selectFullname(usernameSaver));
                }
                catch (SQLException eSQLEP){
                    eSQLEP.printStackTrace();
                }
                frameEP.setVisible(true);
            }
        });

        menuAbout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frameAbout.setVisible(true);
            }
        });

        menuLogout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frameInside.dispose();
                frameUtama.setVisible(true);
            }
        });

        buttonShowIncomeIs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try{
                    Vector<Vector<Object>> data1 = null;
                    Vector<Object> columnNames = new Vector<Object>();
                    columnNames.add("Username");
                    columnNames.add("Tanggal Transaksi");
                    columnNames.add("Transaksi");
                    columnNames.add("Notes");
                    data1 = db.selectIncome(usernameSaver);

                    JTable table1 = new JTable(data1, columnNames);
                    JScrollPane scrollPane = new JScrollPane(table1);
                    table1.setFillsViewportHeight(true);
                    table1.setEnabled(false);

                    frameTabel1.add(scrollPane, BorderLayout.CENTER);



                    frameTabel1.setVisible(true);


                }
                catch(SQLException eSQL){


                }

            }
        });

        buttonSortIs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try{
                    Vector<Vector<Object>> data4 = null;
                    Vector<Object> columnNames = new Vector<Object>();
                    columnNames.add("Username");
                    columnNames.add("Tanggal Transaksi");
                    columnNames.add("Transaksi");
                    columnNames.add("Notes");
                    data4 = db.selectSortIs(usernameSaver);

                    JTable table4 = new JTable(data4, columnNames);
                    JScrollPane scrollPane = new JScrollPane(table4);
                    table4.setFillsViewportHeight(true);
                    table4.setEnabled(false);

                    frameTabel3.add(scrollPane, BorderLayout.CENTER);



                    frameTabel3.setVisible(true);


                }
                catch(SQLException eSQL){


                }

            }
        });

        buttonSortEs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try{
                    Vector<Vector<Object>> data5 = null;
                    Vector<Object> columnNames = new Vector<Object>();
                    columnNames.add("Username");
                    columnNames.add("Tanggal Transaksi");
                    columnNames.add("Transaksi");
                    columnNames.add("Notes");
                    data5 = db.selectSortEs(usernameSaver);

                    JTable table5 = new JTable(data5, columnNames);
                    JScrollPane scrollPane = new JScrollPane(table5);
                    table5.setFillsViewportHeight(true);
                    table5.setEnabled(false);

                    frameTabel4.add(scrollPane, BorderLayout.CENTER);



                    frameTabel4.setVisible(true);


                }
                catch(SQLException eSQL){


                }

            }
        });

        buttonShowBigEs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try {
                    JOptionPane.showMessageDialog(null,db.selectMaxEs(usernameSaver), "Warning !", JOptionPane.INFORMATION_MESSAGE);
                }
                catch(SQLException eSQL){
                    eSQL.printStackTrace();

                }

            }
        });

        buttonShowBigIs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try{
                    JOptionPane.showMessageDialog(null,db.selectMaxIs(usernameSaver), "Warning !", JOptionPane.INFORMATION_MESSAGE);
                }
                catch(SQLException eSQL){
                }
            }
        });

        buttonShowIncomeEs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try{
                    Vector<Vector<Object>> data3 = null;
                    Vector<Object> columnNames = new Vector<Object>();
                    columnNames.add("Username");
                    columnNames.add("Tanggal Transaksi");
                    columnNames.add("Transaksi");
                    columnNames.add("Notes");
                    data3 = db.selectExpense(usernameSaver);

                    JTable table3 = new JTable(data3, columnNames);
                    JScrollPane scrollPane = new JScrollPane(table3);
                    table3.setFillsViewportHeight(true);
                    table3.setEnabled(false);

                    frameTabel2.add(scrollPane, BorderLayout.CENTER);



                    frameTabel2.setVisible(true);


                }
                catch(SQLException eSQL){


                }

            }
        });

        buttonBalance.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {

                try{
                    Vector<Vector<Object>> data = null;
                    Vector<Object> columnNames = new Vector<Object>();
                    columnNames.add("Username");
                    columnNames.add("Tanggal Transaksi");
                    columnNames.add("Transaksi");
                    columnNames.add("Notes");
                    data = db.selectBalance(usernameSaver);

                    JTable table2 = new JTable(data, columnNames);
                    JScrollPane scrollPane = new JScrollPane(table2);
                    table2.setFillsViewportHeight(true);
                    table2.setEnabled(false);

                    frameTabel.add(scrollPane, BorderLayout.CENTER);



                    frameTabel.setVisible(true);


                }
                catch(SQLException eSQL){


                }

            }
        });
        buttonAddIncomeIs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {

                frameAddIncomeIs.setVisible(true);

            }
        });

        buttonAddExpenseIs.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                frameAddExpenseIs.setVisible(true);

            }
        });
//----------------------------------------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------------------------------------
        //BUTTON LOGIN frameUtama
        buttonLogin.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                if(!textBoxUsername.equals("") && !textBoxPassword.equals("")){
                    try {
                        adaUser = db.userLogin(textBoxUsername.getText(), textBoxPassword.getText());
                        if(adaUser){
                            usernameSaver = textBoxUsername.getText();
                            passwordSaver = textBoxPassword.getText();
                            //HARUS DIUBAH JADI FRAME UTAMA NANTI
                            textBoxUsername.setText("");
                            textBoxPassword.setText("");
                            frameInside.setVisible(true);
                            frameUtama.setVisible(false);
                        }
                        else{
                            textBoxPassword.setText("");
                            JOptionPane.showMessageDialog(null,"Wrong username/password, Please ensure your caps lock is off", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                    catch (Exception eL){
                        eL.printStackTrace();
                    }

                }
                else {
                    JOptionPane.showMessageDialog(null,"Please fill your username and password !", "Warning !", JOptionPane.INFORMATION_MESSAGE);
                }

            }
        });

        //BUTTON SIGNUP frameUtama
        buttonSignup.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                textBoxUsername.setText("");
                textBoxPassword.setText("");
                frameSignup.setVisible(true);
                frameUtama.setVisible(false);
            }
        });
    }



    public static  void  main(String[] args){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    new Tester().displayGUI();
                }
                catch (Exception e){
                    e.printStackTrace();
                }

            }
        });
    }
}
